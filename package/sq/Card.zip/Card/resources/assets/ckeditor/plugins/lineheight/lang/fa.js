CKEDITOR.plugins.setLang('lineheight','en', {
    title: 'فاصله خط'
} );
