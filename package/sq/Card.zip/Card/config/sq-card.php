<?php
return [
    'barcode-size' => "0.6",
];
