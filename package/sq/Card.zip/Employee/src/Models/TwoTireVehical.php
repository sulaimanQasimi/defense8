<?php

namespace Sq\Employee\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TwoTireVehical extends Model
{
    use HasFactory;
    use SoftDeletes;

}
