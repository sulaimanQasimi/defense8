<?php

namespace Sq\Employee\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmployeeOption extends Model
{
    use HasFactory;
    protected $table="employee_option_related";
}
